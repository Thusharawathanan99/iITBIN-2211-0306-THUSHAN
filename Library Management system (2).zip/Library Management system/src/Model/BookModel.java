package Model;

import java.sql.Statement;

public class BookModel {
    Statement stmt;

    public void Form(String BookID, String Name, String Publisher) {
        try {
            stmt = DBConnection.getStatementConnection();
            // Explicitly list the column names to match the provided values
            String query = "INSERT INTO books (BookID, Name, Publiser) VALUES ('" + BookID + "', '" + Name + "', '" + Publisher + "')";
            stmt.executeUpdate(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
