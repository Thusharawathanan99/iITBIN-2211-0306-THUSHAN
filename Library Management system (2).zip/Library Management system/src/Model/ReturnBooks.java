package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class ReturnBooks {
     Statement stmt;
   public void Form(String BookID, String StudentId, String IssueDate,String DUEDATE) {
        try {
            stmt = DBConnection.getStatementConnection();
            // Explicitly list the column names to match the provided values
           String query = "INSERT INTO `return book` (BookID, studentID, IssueDate, DueDate) VALUES ('" 
    + BookID + "', '" +  StudentId + "', '" +  IssueDate + "', '" + DUEDATE + "')";

            stmt.executeUpdate(query);
        } catch (Exception e) {
            e.printStackTrace();
        }

    // Removed the Form method that throws UnsupportedOperationException
}
}
