/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Statement;

/**
 *
 * @author thami
 */
public class IssueBookModel {
    
    Statement stmt;

    public void Form(String BookID, String StudentId, String IssueDate) {
        try {
            stmt = DBConnection.getStatementConnection();
            // Explicitly list the column names to match the provided values
            String query = "INSERT INTO Issuebooks (BookID, StudentId, IssueDate) VALUES ('" 
                    + BookID + "', '" + StudentId + "', '" + IssueDate + "')";
            stmt.executeUpdate(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
