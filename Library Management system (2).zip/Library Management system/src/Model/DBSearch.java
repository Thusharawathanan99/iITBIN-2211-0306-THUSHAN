/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author thami
 */
public class DBSearch {
    Statement stmt;
 ResultSet rs;
public ResultSet searchLogin(String usName) {
 try {
 stmt = DBConnection.getStatementConnection();
 String name = usName;
//Execute the Query
rs = stmt.executeQuery("SELECT * FROM login where username='" + name + "'");
 } catch (Exception e) {
 e.printStackTrace();
 }
 return rs;
 }



    public ResultSet searchissuebook() {
       try {
 stmt = DBConnection.getStatementConnection();

//Execute the Query
rs = stmt.executeQuery("SELECT * FROM issuebooks ");
 } catch (Exception e) {
 e.printStackTrace();
 }
 return rs;
    }
    
     public ResultSet searchRETURNbook() {
       try {
 stmt = DBConnection.getStatementConnection();

//Execute the Query
rs = stmt.executeQuery("SELECT * FROM `return book` ");
 } catch (Exception e) {
 e.printStackTrace();
 }
 return rs;
    }

}
