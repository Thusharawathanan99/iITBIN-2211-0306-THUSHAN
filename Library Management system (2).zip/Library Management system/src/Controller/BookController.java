
package Controller;

import javax.swing.JOptionPane;

/**
 *
 * @author thami
 */
public class BookController {
    public static void Form(String BookID, String Name, String Publiser) {
 new Model. BookModel().Form( BookID, Name, Publiser);
 JOptionPane.showMessageDialog(null, "New Record has been inserted", "Successfull", 
JOptionPane.INFORMATION_MESSAGE);
} 
}
