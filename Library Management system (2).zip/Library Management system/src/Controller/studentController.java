/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import javax.swing.JOptionPane;

/**
 *
 * @author thami
 */
public class studentController {
    public static void Form(String student_ID, String student_name, String FatherName, String CourseName,String BranchName) {
 new Model. studentModel().Form(student_ID, student_name, FatherName, CourseName, BranchName);
 JOptionPane.showMessageDialog(null, "New Record has been inserted", "Successfull", 
JOptionPane.INFORMATION_MESSAGE);
} 
}
